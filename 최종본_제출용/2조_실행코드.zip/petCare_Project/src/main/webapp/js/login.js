
function openFindIdPage() {
	window.open('FindId.jsp', '_blank', 'width=550, height=700, top=150');
}
function openFindPwPage() {
	window.open('FindPw.jsp', '_blank', 'width=550, height=700, top=150');
}

